package ru.alishev.springcourse.Project2Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project2BootApplicationTests {

	@Test
	void contextLoads() {
	}

}
